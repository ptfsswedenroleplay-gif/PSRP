const DEFAULTS = {
  username: "PSRP",
  // Initial password is set by setupAdmin(). Change it after first login.
  status: "bemannad",
  reason: "",
  welcomeTitle: "VÄLKOMMEN TILL PSRP",
  welcomeText: "Välkommen till vår server. Här hittar du aktuell information och serverstatus.",
  gameUrl: "",
  discordUrl: "",
  bannerUrl: "",
  channels: [
    { name: "Information", description: "Viktig information från PSRP.", url: "" },
    { name: "Support", description: "Få hjälp av personalen.", url: "" },
    { name: "Ansökningar", description: "Här hittar du våra ansökningar.", url: "" }
  ]
};

function doGet() {
  return HtmlService.createHtmlOutputFromFile("Index")
    .setTitle("PSRP – Officiell webbplats")
    .addMetaTag("viewport", "width=device-width, initial-scale=1");
}

/**
 * Run this function ONCE from the Apps Script editor before deployment.
 * It creates the initial admin account: username PSRP, password PSRP.
 * Change the password immediately after signing in.
 */
function setupAdmin() {
  const p = PropertiesService.getScriptProperties();
  if (!p.getProperty("ADMIN_HASH")) {
    p.setProperty("ADMIN_USERNAME", DEFAULTS.username);
    p.setProperty("ADMIN_HASH", hashPassword_("PSRP"));
  }
  if (!p.getProperty("SITE_DATA")) {
    p.setProperty("SITE_DATA", JSON.stringify(DEFAULTS));
  }
  return "PSRP setup complete.";
}

function getPublicData() {
  const data = readData_();
  return {
    status: data.status,
    reason: data.reason,
    welcomeTitle: data.welcomeTitle,
    welcomeText: data.welcomeText,
    gameUrl: data.gameUrl,
    discordUrl: data.discordUrl,
    bannerUrl: data.bannerUrl,
    channels: data.channels || []
  };
}

function login(username, password) {
  const p = PropertiesService.getScriptProperties();
  const savedUser = p.getProperty("ADMIN_USERNAME");
  const savedHash = p.getProperty("ADMIN_HASH");
  if (!savedUser || !savedHash) throw new Error("Administratörskontot är inte konfigurerat.");
  if (String(username || "").trim() !== savedUser || hashPassword_(String(password || "")) !== savedHash) {
    throw new Error("Fel användarnamn eller lösenord.");
  }
  const token = Utilities.getUuid();
  CacheService.getScriptCache().put("admin_" + token, "valid", 21600);
  return token;
}

function logout(token) {
  if (token) CacheService.getScriptCache().remove("admin_" + token);
  return true;
}

function saveAdminData(token, input) {
  requireAdmin_(token);
  const old = readData_();
  const clean = {
    ...old,
    status: ["stangd", "obemannad", "bemannad"].includes(input.status) ? input.status : old.status,
    reason: String(input.reason || "").slice(0, 500),
    welcomeTitle: String(input.welcomeTitle || "").slice(0, 100),
    welcomeText: String(input.welcomeText || "").slice(0, 500),
    gameUrl: safeUrl_(input.gameUrl),
    discordUrl: safeUrl_(input.discordUrl),
    bannerUrl: safeUrl_(input.bannerUrl),
    channels: Array.isArray(input.channels) ? input.channels.slice(0, 30).map(c => ({
      name: String(c.name || "").slice(0, 60),
      description: String(c.description || "").slice(0, 180),
      url: safeUrl_(c.url)
    })).filter(c => c.name) : old.channels
  };
  PropertiesService.getScriptProperties().setProperty("SITE_DATA", JSON.stringify(clean));
  return getPublicData();
}

function changeAdminPassword(token, newPassword) {
  requireAdmin_(token);
  const pass = String(newPassword || "");
  if (pass.length < 12) throw new Error("Lösenordet måste innehålla minst 12 tecken.");
  PropertiesService.getScriptProperties().setProperty("ADMIN_HASH", hashPassword_(pass));
  return true;
}

function readData_() {
  const raw = PropertiesService.getScriptProperties().getProperty("SITE_DATA");
  if (!raw) return JSON.parse(JSON.stringify(DEFAULTS));
  try { return { ...DEFAULTS, ...JSON.parse(raw) }; }
  catch (e) { return JSON.parse(JSON.stringify(DEFAULTS)); }
}

function requireAdmin_(token) {
  if (!token || CacheService.getScriptCache().get("admin_" + token) !== "valid") {
    throw new Error("Din inloggning har gått ut. Logga in igen.");
  }
}

function hashPassword_(password) {
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, password, Utilities.Charset.UTF_8);
  return bytes.map(b => (b + 256).toString(16).slice(-2)).join("");
}

function safeUrl_(value) {
  const s = String(value || "").trim();
  if (!s) return "";
  if (!/^https:\/\/[^\s]+$/i.test(s)) throw new Error("Alla länkar måste börja med https://");
  return s;
}
