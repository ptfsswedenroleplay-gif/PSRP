-- PSRP database setup for Supabase.
-- Run this entire file once in Supabase Dashboard > SQL Editor > New query.

create table if not exists public.site_settings (
  id integer primary key check (id = 1),
  status text not null default 'bemannad' check (status in ('bemannad','obemannad','stangd')),
  reason text not null default '',
  welcome_title text not null default 'VÄLKOMMEN TILL PSRP',
  welcome_text text not null default 'Välkommen till PSRP – PTFS Sweden Roleplay. Här hittar du aktuell information, serverstatus och våra kommunikationskanaler.',
  game_url text not null default '',
  discord_url text not null default '',
  banner_url text not null default '',
  channels jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);

insert into public.site_settings (id, channels)
values (1, '[
  {"name":"Information","description":"Viktig information från PSRP.","url":""},
  {"name":"Support","description":"Få hjälp av personalen.","url":""},
  {"name":"Ansökningar","description":"Information om ansökningar.","url":""}
]'::jsonb)
on conflict (id) do nothing;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.site_settings enable row level security;
alter table public.admin_users enable row level security;

-- Everyone can read the public website settings.
drop policy if exists "Public can read PSRP settings" on public.site_settings;
create policy "Public can read PSRP settings"
on public.site_settings for select
using (true);

-- Only users explicitly listed in admin_users can read their own admin membership.
drop policy if exists "Admins can read own membership" on public.admin_users;
create policy "Admins can read own membership"
on public.admin_users for select to authenticated
using (user_id = auth.uid());

-- Only listed admins can change the website settings.
drop policy if exists "PSRP admins can update settings" on public.site_settings;
create policy "PSRP admins can update settings"
on public.site_settings for update to authenticated
using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()))
with check (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

grant select on public.site_settings to anon, authenticated;
grant update on public.site_settings to authenticated;
grant select on public.admin_users to authenticated;
