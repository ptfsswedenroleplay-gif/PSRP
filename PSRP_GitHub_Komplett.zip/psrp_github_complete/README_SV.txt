PSRP – GitHub Pages + Supabase

FILER
- index.html: hela webbplatsens frontend.
- supabase_setup.sql: databas och säkerhetsregler.

VIKTIGT
Den här versionen är gjord för GitHub Pages. Den använder Supabase för inloggning och för att spara ändringar. GitHub Pages kan inte i sig själv spara administratörsändringar.

1. SKAPA SUPABASE-PROJEKT
- Gå till https://supabase.com/ och skapa ett projekt på Free-planen.
- Skapa det tillsammans med en vårdnadshavare om registrering/betalningsuppgifter efterfrågas. Välj inte någon betald plan.
- Öppna SQL Editor > New query.
- Öppna supabase_setup.sql, kopiera hela innehållet, klistra in i SQL Editor och tryck Run.

2. SKAPA ADMINANVÄNDARE
- I Supabase öppnar du Authentication > Users och väljer Add user.
- Skapa administratörens e-postadress och ett starkt, unikt lösenord. Använd inte PSRP/PSRP.
- Kopiera användarens UUID/ID från Users-listan.
- Öppna SQL Editor och kör följande, men byt ut UUID mot användarens riktiga ID:

  insert into public.admin_users (user_id)
  values ('KLISTRA-IN-ADMIN-UUID-HAR');

- Lämna inte ut lösenordet till någon. Publicera aldrig service_role/secret key.

3. HÄMTA SUPABASE-ANSUTNING
- Öppna Project Settings > API (eller API Keys i nya gränssnittet).
- Kopiera Project URL.
- Kopiera Publishable key (äldre projekt kan visa anon public key).
- Använd aldrig service_role eller secret key i index.html.

4. FYLL I index.html
Nära slutet av index.html finns två rader:
window.PSRP_SUPABASE_URL = 'KLIStra_IN_DITT_SUPABASE_PROJECT_URL_HAR';
window.PSRP_SUPABASE_ANON_KEY = 'KLIStra_IN_DIN_SUPABASE_PUBLISHABLE_KEY_HAR';
Ersätt bara texten mellan citattecknen med Project URL och Publishable/anon key.

5. LÄGG UPP PÅ GITHUB
- Öppna ditt repository psrp.
- Add file > Upload files.
- Ladda upp index.html.
- Commit changes.
- Du kan även ladda upp README_SV.txt och supabase_setup.sql som dokumentation.
- Gå till Settings > Pages. Under Build and deployment välj Deploy from a branch, branch main och folder /(root). Spara.
- Vänta tills GitHub Pages visar publicerad webbplats.

6. TESTA
- Öppna webbplatsen. Den ska visa PSRP:s startsida.
- Administratörsinloggning finns längst ned.
- Logga in med den e-postadress och det lösenord du skapade i Supabase.
- Bara UUID som finns i admin_users får ändra webbplatsen.

SÄKERHET OCH BEGRÄNSNINGAR
- Supabase Free är gratis inom sina aktuella gränser. Gratisprojekt kan pausas efter inaktivitet; kontrollera aktuell pris- och användningsinformation.
- Publicera aldrig Supabase service_role/secret key i HTML, GitHub eller någon offentlig fil.
- Publishable/anon key får finnas i webbsidan endast tillsammans med Row Level Security-policys som i SQL-filen.
- Spara inte privata uppgifter i de offentliga webbplatsinställningarna.
- Om Supabase-projektet pausas eller når gränserna kan webbplatsen visas men administratörsändringar kanske inte fungerar förrän tjänsten är aktiv igen.
